/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import java.util.Random;
/**
 *
 * @author Seb
 */
public class Graph extends JApplet implements Runnable{

     Thread animator;
     
     boolean Auto1 = true;
//variables for animating the cloud
    int Auto1X;
    int Auto1Y;
    int Auto1tracker = 0;

    BufferedImage img;
    Graphics g2;
    
    @Override
    public void init() {
        JRootPane root = this.getRootPane();
        root.putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);
    }
     
    @Override
    public void start()
    {
       img = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_ARGB);
       g2 = img.createGraphics();
        Auto1X = 920;
         Auto1Y = 1000;
       animator = new Thread(this);
       animator.start();
          
    }
    
    @Override
    public void stop()
    {
       animator = null;
    }

    @Override
    public void destroy()
    {
     
    }

    @Override
    public void paint(Graphics g) {
       
 //achtergrond
        g2.setColor(Color.green);
        g2.fillRect(0,0, getWidth(), getHeight());        
///eerste weg
        g2.setColor(new Color(96, 96, 96));
        g2.fillRect(0, 380, 700, 60);
        g2.fillRect(0, 440, 700, 60);
        g2.setColor(new Color(255, 255, 255));
        g2.fillRect(0, 440, 700, 3);
        
        g2.setColor(new Color(96, 96, 96));
        g2.fillRect(0, 380, 2000, 1);
        
        ///tweede weg
        g2.setColor(new Color(96, 96, 96));
        g2.fillRect(1210, 380, 700, 60);
        g2.fillRect(1210, 440, 700, 60);
        g2.setColor(new Color(255, 255, 255));
        g2.fillRect(1210, 440, 700, 3);
        
       //hulplijnen
       g2.setColor(new Color(96, 96, 96));
        g2.fillRect(0, 380, 2000, 1); 
       
        g2.setColor(new Color(96, 96, 96));
        g2.fillRect(0, 500, 2000, 1);
        ///Derde weg
        g2.setColor(new Color(96, 96, 96));
        g2.fillRect(900, 0, 60, 380);
        g2.fillRect(960, 0, 60, 380);
        g2.setColor(new Color(255, 255, 255));
        g2.fillRect(960, 0, 3, 380);
        
        ///Vierde weg
        g2.setColor(new Color(96, 96, 96));
        g2.fillRect(900, 500, 60, 380);
        g2.fillRect(960, 500, 60, 380);
        g2.setColor(new Color(255, 255, 255));
        g2.fillRect(960, 500, 3, 380);
        
        //auto1
        g2.setColor(Color.black);
        g2.fillRect(Auto1X, Auto1Y, 20, 50);
        
        
        
        g.drawImage(img, 0, 0, this);
    }
public static void main(String s[]) {
        JFrame f = new JFrame("Java Graphics");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JApplet applet = new Graph();
        f.getContentPane().add(applet);
        applet.init();
        f.pack();
        f.setSize(new Dimension(1920, 1080));
        f.setVisible(true);
        applet.start();
    }
     
 public void run() {
        while (Thread.currentThread() == animator) {

           if (Auto1){
                if (Auto1Y > 10)
                    Auto1Y--;
                Auto1Y--;
                Auto1Y--;
                Auto1Y--;
          if (Auto1Y == 10) {
                    Auto1Y = 1000;
          }
                 repaint();
            
                 try {
                Thread.sleep(27); //time in milliseconds
            }
            catch (Exception e) {
                break;
            }
        }}}}
